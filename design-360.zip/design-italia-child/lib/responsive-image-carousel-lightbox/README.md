# lightbox
simple lightbox with jQuery

demo: http://karolinaklein.pl/dev/lightbox/
