<?php
/**
 *Modifiche Riccardo Testa
 *
 */

if (!defined('ABSPATH')) {
    die('-1');
}

$events_label_singular = tribe_get_event_label_singular();
$events_label_plural = tribe_get_event_label_plural();

$event_id = get_the_ID();

// Setup an array of venue details for use later in the template
$venue_details = tribe_get_venue_details();

// The address string via tribe_get_venue_details will often be populated even when there's
// no address, so let's get the address string on its own for a couple of checks below.
$venue_address = tribe_get_address();

// Venue
$has_venue_address = (!empty($venue_details['address'])) ? ' location' : '';

// Organizer
$organizer = tribe_get_organizer();

?>
<style>


    .sfondo {
        background-image: url("http://turismoacquiterme.it/visit/wp-content/uploads/2016/05/ACQUI-FOR-EVENTS.jpg");
        background-size: cover;
        min-height: 400px;
        position: relative;
        width: 110%;
        margin-top: -3.5%;
        margin-bottom: 2%;
        background-position: top;
        background-position-x: center;
        left: -5%;
    }

    .gradient {
        /* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#000000+0,000000+100&0+0,0.65+100 */
        background: -moz-linear-gradient(top, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0.65) 100%); /* FF3.6-15 */
        background: -webkit-linear-gradient(top, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0.65) 100%); /* Chrome10-25,Safari5.1-6 */
        background: linear-gradient(to bottom, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0.65) 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
        filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#00000000', endColorstr='#a6000000', GradientType=0); /* IE6-9 */

        background-size: cover;
        min-height: 400px;
    }

    .titolo-over {
        position: relative;
        top: 200px;
        left: 20%;
        color: white !important;
    }

    .title {
        font-size: 5em;
        font-weight: 500;

    }

    .subtitle {

        font-size: 1em;
        font-weight: 300;

    }

    .navigation {
        position: relative;
        padding: 2%;
        background: rgb(242, 242, 242);
    }
    .dati-evento-footer {
        font-size: 1.2em;
        font-weight: 500!important;
        margin-right: 10px;
        padding-top: 2%;
        text-align: center;
        background:rgb(242, 242, 242);
    }

    .dati-evento-top {
        font-size: 1.2em;
        font-weight: 500!important;
        margin-right: 10px;
        padding-bottom: 2%;
        text-align: center;
        background:rgb(242, 242, 242);
    }
    .dati-evento-left {
        font-size: 1.2em;
        font-weight: 500!important;
        margin-right: 5px;
        text-align: center;
        background:rgb(242, 242, 242);
      
    }

    .dati-evento-left > div {
        font-size: 1.2em;
        font-weight: 500!important;
        margin-right: 5px;
        text-align: center;
        background:rgb(242, 242, 242);
        padding: 3%;
    }
    span.dati-evento-top {
        vertical-align: middle
    }

    .icofont {
        font-size: 2em !important;
    }
    .icofont:hover {
        font-size: 2em !important;
        color:blue;
    }
    .titolo{
        text-transform: uppercase;
        text-align:center;
        font-weight:300!important;
        /*padding:3%;*/
        background:rgb(242, 242, 242);
    }
    .event-organiz{
      
        text-align:center;
        font-weight:700!important;
        padding:3%;
        padding-left:5%;
        background:#e6f2ff;  
        margin-bottom:15px;
    }
    

.tribe-events-event-image {
    margin-bottom: 0.2em;
    text-align: center;}
    .immagine>div>img{
        max-width:100%;
        
    
    }
    .row{
        padding:1%!important;
        margin-left:0px;
        margin-right:0px;
    }
    .container-fluid{
        width:108%;
        /*margin-left:-3%;
        margin-right:-3%;*/
        
    }
    
    .data-from-to{
        font-size:0.9em;
    }
    .tribe-events-single-event-description{
        text-align:left;
    }
    
</style>

<!-- Intestazione banner-->
<div class="sfondo">
    <div class="gradient">
        <div class="titolo-over">
            <p class="title">Eventi</p>
            <?php the_title('<span class="subtitle">', '</span>'); ?>
        </div>
    </div>
    <!-- Menu di navigazione -->
    <div class="navigation">
        <a href="<?php echo esc_url(tribe_get_events_link()); ?>"> Visualizza la lista degli eventi -
            <?php printf('&laquo; ' . esc_html_x('All %s', '%s Events plural label', 'the-events-calendar'), $events_label_plural); ?></a>
    </div>
</div>

<!-- #Layout EVENTO -->

<?php while (have_posts()) :
the_post(); ?>

<div class="container-fluid">
<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <div class=" row">
        <div class="col-md-2" style="padding: 0px !important; margin: 0px; left: -3.5%;!important">
            <div class="row dati-evento-left">
                <!-- Blocco Dati anteprima -->
            
                <div class="col-md-12">
                    
                        <!-- Data-->
                        <div class="tribe-event-schedule-details">
                            <i class="icofont icofont-ui-calendar"></i>
                            <?php 
                            $from=tribe_get_start_date(null, false, 'l d F');
                            $to=tribe_get_end_date(null, false, 'l d F');
                            if($from==$to){
                               ?>
                               <p class="data-from-to"><strong><?php echo $from; ?></strong>
                                                        </p>
                                                        <?php
                            }
                            else{
                                ?><p class="data-from-to"><strong><?php echo $from; ?></strong>
                            <br>fino a<br><strong><?php echo $to; ?></strong>
                            </p>
                                <?php
                            }
                            ?>
                            
                        </div>
                    
                </div>
                <div class="col-md-12">
                    <!-- Luogo -->
                    <div class="event-luogo">
                        <?php if ($venue_details) : ?>
                            <!--Venue -->
                            <div class="tribe-events-venue-details">
                                <?php
                                $address_delimiter = empty($venue_address) ? ' ' : ', ';

                                // These details are already escaped in various ways earlier in the process.?>
                                <i class="icofont icofont-location-pin"></i><br>
                                <?php

                                $i = 0;
                                echo $venue_details[1];
                                foreach ($venue_details as $el) {

                                    if ($i < 1) {
                                        echo $el;
                                    } else {
                                        break;
                                    }
                                    $i++;

                                }

                                if (tribe_show_google_map_link()) {
                                    //echo tribe_get_map_link_html();
                                }
                                ?>
                            </div> <!-- .tribe-events-venue-details -->
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-md-12">
                    <!-- Orario-->
                    <div class="tribe-event-schedule-details">
                        <i class="icofont icofont-clock-time"></i><br>
                        <?php 
                        $starttime=tribe_get_start_time(null, false, 'g:i');
                        $stoptime=tribe_get_end_time(null, false, 'g:i');
                          if(tribe_event_is_all_day()){
                              echo "24h";
                          }
                          else{
                              if($starttime!=null){
                                  echo $starttime;
                              }
                              if($stopttime!=null){
                                  echo $stoptime;
                              }
                          }
                      ?>
                    </div>
                </div>
                
                <div class="col-md-12">
                    <!-- Costo-->
                    <div class="tribe-event-schedule-details">
                       
                        <!-- Event Cost -->
                    <?php if (tribe_get_cost()) : ?>
                            <i class="icofont icofont-cur-euro"></i><br>
                            <?php echo tribe_get_cost(null, false); ?>
                            <?php
                            /**
                             * Runs after cost is displayed in list style views
                             *
                             * @since 4.5
                             */
                            do_action('tribe_events_inside_cost')
                            ?>
                        
                    <?php endif; ?>
                        
                    </div>
                </div>
                
                
            </div>
        </div>
        <div class="col-md-7" style="padding: 0px !important;"  >
            
                           <!-- Categoria-->

             <div class="row dati-evento-top">
                    <div class="col-md-12 event-category">
                        <i class="icofont icofont-square-down"></i><br> <?php echo Tribe_Register_Meta::event_category('tribe_event_category') ?>
                    </div>
             </div>
             
             <div class="row dati-evento-top">
                <!-- Blocco Titolo & Immagine  -->
                <div class="col-md-12 titolo">

                    <!-- Event Title -->
                    <?php do_action('tribe_events_before_the_event_title') ?>
                    <h2 class="tribe-events-list-event-title">
                        <a class="tribe-event-url" href="<?php echo esc_url(tribe_get_event_link()); ?>"
                           title="<?php the_title_attribute() ?>" rel="bookmark">
                            <?php the_title() ?>
                        </a>
                    </h2>
                    <?php do_action('tribe_events_after_the_event_title') ?>

                     </div>
            </div>
                    <div class="row dati-evento-top">
                    <div class="col-md-12 immagine">
                    <!-- Immagine evento  -->
                    <div class="immagine">
                    <?php echo tribe_event_featured_image($event_id, 'full', false); ?>
                    </div>
                   
                     </div>


                <div class="col-md-12 content-event">
                    <!-- Organizer PATROCINIO -->
                    <?php  $type=tribe_get_custom_field('comune');
                    if($type=="Patrocinato"){
                        echo "<div class='event-organiz'>Patrocinio del Comune di Acqui Terme</div>";
                    }
                    if($type=="Organizzato"){
                        echo "<div class='event-organiz'>Organizzato dal Comune di Acqui Terme</div>";
                    }
                    ?>
                    <!-- Organizer -->
                    <?php if (tribe_has_organizer()){
                        ?>
                        <div class="event-organiz" style="display:none">
                        <div><h5>Organizzato da: <?php echo tribe_get_organizer();?></div></h5><hr>
                        <?php 
                        $mail=tribe_get_organizer_email();
                        $web=tribe_get_organizer_website_url();
                        $phone=tribe_get_organizer_phone();?>
                        <?php if($mail!=""){?>
                        <div><i class="icofont icofont-ui-email"></i> <a href="mailto:<?php echo $mail;?>"><?php echo $mail;?></a></div>
                        <?php }
                        if($web!=""){?>
                        <div><i class="icofont icofont-web"></i> <a href="<?php echo $web;?>"><?php echo $web;?></a></div>
                        <?php }
                        if($phone!=""){?>
                        <div><i class="icofont icofont-phone"></i> <?php echo $phone;?></div>
                        <?php }?>
                        </div>
                        <?php
                        
                    }
                    ?>
                    <?php do_action('tribe_events_after_the_meta') ?>
                    </div>
            <div class="row">
                    <!-- Event content -->
                    <?php do_action('tribe_events_single_event_before_the_content') ?>
                    <div class="tribe-events-single-event-description tribe-events-content">
                        <?php the_content();
                        ?>
                    </div>
                    
                </div>
            </div>
                <!-- ----------------------OOOOOOOOOOOOOOOOOOOOOOOOOOOOO-------------- -->
            
            <!-- Scarica l'evento -->
            <div class="row" id="maps">
                <div class="col-md-12 condivide">
                        <?php do_action('tribe_events_single_event_after_the_content') ?></div>
            </div>

            <!-- Mappa -->
            <div class="row" id="maps">
                <div class="col-md-12">
                    <?php if (tribe_show_google_map_link()) {
                        echo tribe_get_map_link_html();
                        echo tribe_get_embedded_map();
                       
                    }


                    ?>

                </div>
            </div>
        </div>
        <div>
            <?php get_sidebar() ?>
        </div>
    </div>

</div>
</div>
<!-- #post-x -->
		
		<?php if (get_post_type() == Tribe__Events__Main::POSTTYPE && tribe_get_option('showComments', false)) comments_template() ?>
	<?php endwhile; ?>
<div class="row dati-evento-footer">
        <div class="col-md-12">
    <!-- Navigation -->
    <h3 class="tribe-events-visuallyhidden"><?php printf(esc_html__('%s Navigation', 'the-events-calendar'), $events_label_singular); ?></h3>
            <?php tribe_the_prev_event_link('<i class="icofont icofont-hand-left"></i> %title%') ?> |
            <?php tribe_the_next_event_link('%title% <i class="icofont icofont-hand-right"></i> ') ?>
    
    <!-- .tribe-events-sub-nav -->
    
    <p>Non si assumono responsabilità per eventuali modifiche ai programmi o per variazioni di data.</p>
<p >Per informazioni: </span><span style="font-weight: bold;">Comune di Acqui Terme</span></p>

<div class="row">
<div class="col-md-6">
<p>Ufficio Turismo e Sport</span></p>
<p>Tel. 0144 770274 / 298</p>

</div>
<div class="col-md-6">
<p>Ufficio Cultura e Pubblica Istruzione</span></p>
<p>Tel. 0144 770272</p>

</div>
</div>
</div>
</div>
<!-- #tribe-events-footer -->

</div><!-- #tribe-events-content -->
